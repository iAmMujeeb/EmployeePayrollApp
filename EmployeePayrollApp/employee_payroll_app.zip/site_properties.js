let site_properties = {
    home_page: "EmployeePayrollHomepage.html", 
    add_emp_payroll_page: "AddEmployeePayrollForm.html"
    };